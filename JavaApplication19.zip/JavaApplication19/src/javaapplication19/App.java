/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication19;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Clarisse Angeline
 */

public class App {



    public static void main(String[] args) {
        ArrayList<Integer> deposits = new ArrayList<>();
        int balance = 0;
        Scanner scn = new Scanner(System.in);

        displayMenu();

        int choice = scn.nextInt();

        while (choice > 0 || choice < 5) {

            clearScreen();

            switch (choice) {
                case 1:
                    System.out.println("Enter the amount you want to deposit: ");
                    int amount = scn.nextInt();
                    deposits.add(amount);
                    balance += amount;
                    break;
                case 2:
                    System.out.println("Enter the amount you want to withdraw: ");
                    int withdrawAmount = scn.nextInt();
                    if (balance < withdrawAmount) {
                        System.out.println("Insufficient balance.");
                    } else {
                        balance -= withdrawAmount;
                        System.out.println("Your new balance is $" + balance);
                    }
                    break;
                case 3:
                    System.out.println("Your current balance is $" + balance);
                    break;
                case 4:
                    insertionSort(deposits);
                    if (deposits.size() == 0) {
                        System.out.println("You don't have any deposits yet.");
                    } else {
                        System.out.println("The deposits in ascending order are:");
                        for (int i = 0; i < deposits.size(); i++) {
                            System.out.println(deposits.get(i));
                        }
                    }
                    break;
                default:
                    System.out.println("Invalid choice.");
            }

            System.out.println("Do you want another transaction? Y/N");
            scn.nextLine();
            String answer = scn.nextLine();

            if (!answer.equalsIgnoreCase("y")) {
                break;
            }

            displayMenu();

            choice = scn.nextInt();
        }

        scn.close();

        System.out.println("Thank you for using the banking system!");
    }

    static void displayMenu() {
        System.out.println("What would you like to do?");
        System.out.println("1. Deposit money");
        System.out.println("2. Withdraw money");
        System.out.println("3. View current balance");
        System.out.println("4. View deposits in ascending order");
        // System.out.println("5. Exit");
    }

    static void clearScreen() {
        try {
            if (System.getProperty("os.name").contains("Windows")) {
                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            } else {
                System.out.print("\033\143");
            }
        } catch (IOException | InterruptedException ex) {
        }
    }

    static void insertionSort(ArrayList<Integer> list) {
        for (int i = 1; i < list.size(); i++) {
            int current = list.get(i);
            int j = i - 1;

            while (j >= 0 && list.get(j) > current) {
                list.set(j + 1, list.get(j));
                j--;
            }

            list.set(j + 1, current);
        }
    }
}

